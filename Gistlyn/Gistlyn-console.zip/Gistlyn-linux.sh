#!/bin/bash
mono ./bin/Gistlyn.AppConsole.exe